SMALTI — PRESS KIT
==================
Smalti is a calm restoration game for iPhone by NinjaApps.
These assets are provided for editorial coverage of Smalti.

Contents
  icons/         App icon renders: 1024, 180, 60 px — light, dark, tinted
  wordmark/      Smalti wordmark — vector SVG + transparent PNG, light + dark
  screenshots/   Gameplay captures, 1320x2868 (iPhone 16 Pro Max)
  smalti-fact-sheet.pdf

B-roll and gameplay capture loops are available on request while the
commissioned audio is finished: press@ninjaapps.net

ninjaapps.net/games/smalti/
